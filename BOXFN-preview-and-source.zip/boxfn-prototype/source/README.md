# BOXFN starter: auth, player profile and match history

This is a starter project for the BOXFN.pl website. It includes:
- Supabase Auth signup/login/logout
- Player profile with display name and Fortnite nickname
- Supabase Postgres schema with Row Level Security (RLS)
- Match history restricted to the authenticated participant
- Public player search and public profile pages
- Aggregate player stats: played matches, wins, losses, win rate and starter ELO field
- Dark BOXFN visual design

It does **not** implement token deposits, payments, payouts, matchmaking, game server integration, or trusted match result verification.

## 1. Requirements
- Node.js 20 or newer
- A Supabase project
- A terminal (PowerShell on Windows or Terminal on macOS/Linux)

## 2. Create Supabase project
1. Create a project at https://supabase.com.
2. In Project Settings / API, copy the Project URL and publishable/anon key.
3. In the Supabase SQL Editor, run all of `supabase/schema.sql`. If you previously ran an older version, rerun the updated file; it adds the stats columns with `IF NOT EXISTS`.
4. In Authentication settings, configure the site URL and redirect URLs:
   - Local: `http://localhost:3000/auth/callback`
   - Production: `https://boxfn.pl/auth/callback`
5. For local development, email confirmation may be left on; configure SMTP before public launch for reliable email delivery.

## 3. Configure the app
1. Copy `.env.example` to `.env.local`.
2. Set `NEXT_PUBLIC_SUPABASE_URL` and `NEXT_PUBLIC_SUPABASE_ANON_KEY`.
3. Set `NEXT_PUBLIC_SITE_URL=http://localhost:3000` for local testing. Add this variable to `.env.local` (production should be `https://boxfn.pl`).

Never use a service-role key in browser code or in a `NEXT_PUBLIC_` variable.

## 4. Run locally
```bash
npm install
npm run dev
```
Open http://localhost:3000.

## 5. Deploy
1. Push this project to a private GitHub repository.
2. Import the repository into Vercel.
3. Add `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, and `NEXT_PUBLIC_SITE_URL=https://boxfn.pl` to Vercel environment variables.
4. Deploy, then add `boxfn.pl` and `www.boxfn.pl` in Vercel project Domains.
5. At the domain registrar, set DNS records exactly as Vercel instructs. DNS values depend on current Vercel setup, so do not guess them.
6. Add `https://boxfn.pl/auth/callback` to Supabase Auth redirect URLs and set production Site URL.

## Security notes before production
- Keep RLS enabled.
- Review the profile policies before adding sensitive/private profile fields.
- Public player search requires a signed-in user under the current profile SELECT policy. If you want the directory to be public, review and deliberately change the profile SELECT policy.
- ELO is a placeholder starting value (1000); an actual rating algorithm and season reset are not implemented yet.
- The starter intentionally does not allow browser clients to create matches or set results. Add a trusted server-side workflow with authorization checks, rate limits, audit logs and dispute handling.
- Do not store passwords yourself; Supabase Auth manages them.
- Do not implement money/token ledger changes using client-side updates. A ledger must be append-only and updated transactionally from a trusted backend.
- Add abuse controls, CAPTCHA/rate limiting, password reset, account deletion, privacy policy and terms before launch.
