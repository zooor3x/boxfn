-- BOXFN starter schema for Supabase.
-- Run this in Supabase Dashboard > SQL Editor.
-- Security model: public profiles are readable, only the owner can edit allowed profile fields.
-- Match results should be written only by a trusted server/admin workflow, never by a browser client.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default 'Gracz' check (char_length(display_name) between 2 and 24),
  epic_name text null check (epic_name is null or char_length(epic_name) <= 32),
  matches_played integer not null default 0 check (matches_played >= 0),
  wins integer not null default 0 check (wins >= 0),
  losses integer not null default 0 check (losses >= 0),
  elo_rating integer not null default 1000 check (elo_rating >= 0),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.profiles add column if not exists matches_played integer not null default 0 check (matches_played >= 0);
alter table public.profiles add column if not exists wins integer not null default 0 check (wins >= 0);
alter table public.profiles add column if not exists losses integer not null default 0 check (losses >= 0);
alter table public.profiles add column if not exists elo_rating integer not null default 1000 check (elo_rating >= 0);

alter table public.profiles enable row level security;

drop policy if exists "Profiles are publicly readable" on public.profiles;
create policy "Profiles are publicly readable"
on public.profiles for select
to authenticated
using (true);

drop policy if exists "Players can insert own profile" on public.profiles;
create policy "Players can insert own profile"
on public.profiles for insert
to authenticated
with check (auth.uid() = id);

drop policy if exists "Players can update own profile" on public.profiles;
create policy "Players can update own profile"
on public.profiles for update
to authenticated
using (auth.uid() = id)
with check (auth.uid() = id);

-- Create a profile automatically after a user signs up.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, display_name, epic_name)
  values (
    new.id,
    coalesce(nullif(left(new.raw_user_meta_data ->> 'display_name', 24), ''), 'Gracz'),
    nullif(left(new.raw_user_meta_data ->> 'epic_name', 32), '')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

create table if not exists public.matches (
  id uuid primary key default gen_random_uuid(),
  game_mode text not null check (game_mode in ('box_fight','realistic','zone_wars')),
  team_size smallint not null check (team_size in (1,2,3)),
  queue_type text not null check (queue_type in ('ranked','wagers')),
  status text not null default 'pending' check (status in ('pending','in_progress','completed','disputed','cancelled')),
  winner_team smallint null check (winner_team is null or winner_team in (1,2)),
  created_at timestamptz not null default now(),
  completed_at timestamptz null
);

create table if not exists public.match_participants (
  match_id uuid not null references public.matches(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  team_number smallint not null check (team_number in (1,2)),
  result text not null default 'pending' check (result in ('pending','win','loss','draw')),
  opponent_label text null,
  primary key (match_id, user_id)
);

alter table public.matches enable row level security;
alter table public.match_participants enable row level security;

-- Players can only read matches they participated in.
drop policy if exists "Participants can read own match records" on public.match_participants;
create policy "Participants can read own match records"
on public.match_participants for select
to authenticated
using (auth.uid() = user_id);

drop policy if exists "Participants can read their matches" on public.matches;
create policy "Participants can read their matches"
on public.matches for select
to authenticated
using (
  exists (
    select 1 from public.match_participants mp
    where mp.match_id = matches.id and mp.user_id = auth.uid()
  )
);

-- Deliberately no client INSERT/UPDATE/DELETE policies on matches or match_participants.
-- Use a trusted server-side route with verified auth and strict validation to create/finalize matches.
-- Never put the Supabase service-role key in client-side code.

-- View used by the profile page. Security invoker means underlying RLS still applies.
create or replace view public.my_match_history
with (security_invoker = true)
as
select
  m.id,
  m.game_mode,
  m.team_size,
  m.queue_type,
  mp.result,
  m.created_at,
  mp.opponent_label
from public.match_participants mp
join public.matches m on m.id = mp.match_id
where mp.user_id = auth.uid();

grant select on public.my_match_history to authenticated;

-- Optional: lock down default grants and grant only what app needs.
revoke all on public.profiles from anon;
grant select, insert, update on public.profiles to authenticated;
revoke all on public.matches from anon, authenticated;
grant select on public.matches to authenticated;
revoke all on public.match_participants from anon, authenticated;
grant select on public.match_participants to authenticated;


-- Keep public aggregate statistics in sync only when a trusted backend changes a result
-- from pending to a final outcome. Browser clients have no write policy on participants.
create or replace function public.apply_match_result_stats()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if old.result = 'pending' and new.result in ('win', 'loss', 'draw') then
    update public.profiles
    set matches_played = matches_played + 1,
        wins = wins + case when new.result = 'win' then 1 else 0 end,
        losses = losses + case when new.result = 'loss' then 1 else 0 end,
        updated_at = now()
    where id = new.user_id;
  end if;
  return new;
end;
$$;

drop trigger if exists on_match_result_stats on public.match_participants;
create trigger on_match_result_stats
after update of result on public.match_participants
for each row execute procedure public.apply_match_result_stats();

-- Recreate the view after the schema has been updated.
create or replace view public.my_match_history
with (security_invoker = true)
as
select
  m.id,
  m.game_mode,
  m.team_size,
  m.queue_type,
  mp.result,
  m.created_at,
  mp.opponent_label
from public.match_participants mp
join public.matches m on m.id = mp.match_id
where mp.user_id = auth.uid();

grant select on public.my_match_history to authenticated;
