import Link from "next/link";
import { createClient } from "@/lib/supabase/server";

export default async function Home() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  return <main className="shell">
    <header className="nav">
      <Link href="/" className="brand"><span className="brand-mark">⌖</span> BOXFN</Link>
      <nav className="navlinks">
        <Link href="/players">Szukaj graczy</Link><Link href="/#features">Funkcje</Link>
        {user ? <Link href="/profile">Mój profil</Link> : <><Link href="/login">Logowanie</Link><Link href="/signup" className="btn">Załóż konto</Link></>}
      </nav>
    </header>
    <section className="hero">
      <div className="eyebrow">Fortnite competitive hub</div>
      <h1>Twoja gra.<br/><span style={{color:"var(--lime)"}}>Twoja ranga.</span></h1>
      <p>Jedno konto do profilu gracza, rankingów i historii meczów. To startowy szkielet BOXFN — gotowy do podłączenia do projektu Supabase.</p>
      <div className="row" style={{justifyContent:"flex-start",marginTop:22}}>
        {user ? <Link className="btn" href="/profile">Przejdź do profilu →</Link> : <><Link className="btn" href="/signup">Utwórz konto →</Link><Link className="btn secondary" href="/login">Zaloguj się</Link></>}
      </div>
    </section>
    <section id="features" className="grid">
      <article className="card"><span className="pill">KONTO</span><h2 style={{marginTop:16}}>Bezpieczne logowanie</h2><p>Rejestracja e-mailem i hasłem z sesją obsługiwaną przez Supabase Auth.</p></article>
      <article className="card"><span className="pill">PROFIL</span><h2 style={{marginTop:16}}>Profil gracza</h2><p>Nazwa gracza, nick Fortnite, data utworzenia konta oraz statystyki z bazy.</p></article>
      <article className="card"><span className="pill">MECZE</span><h2 style={{marginTop:16}}>Historia wyników</h2><p>Historia jest widoczna dla zalogowanego gracza tylko dla meczów, w których uczestniczył.</p></article>
    </section>
    <footer>BOXFN — prototyp. Płatności i wypłaty nie są częścią tego startera.</footer>
  </main>;
}
