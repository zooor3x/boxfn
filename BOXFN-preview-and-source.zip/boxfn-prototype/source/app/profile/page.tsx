import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { signOut, updateProfile } from "@/app/actions";

type MatchRow = {
  id: string;
  game_mode: string;
  team_size: number;
  queue_type: string;
  result: string;
  created_at: string;
  opponent_label: string | null;
};

export default async function ProfilePage({ searchParams }: { searchParams: Promise<{error?: string; message?: string}> }) {
  const params = await searchParams;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: profile } = await supabase.from("profiles")
    .select("id, display_name, epic_name, created_at, updated_at, matches_played, wins, losses, elo_rating")
    .eq("id", user.id).maybeSingle();

  const { data: matches } = await supabase.from("my_match_history")
    .select("id, game_mode, team_size, queue_type, result, created_at, opponent_label")
    .order("created_at", { ascending: false }).limit(50);

  const history = (matches ?? []) as MatchRow[];
  const wins = Number(profile?.wins ?? history.filter(m => m.result === "win").length);
  const losses = Number(profile?.losses ?? history.filter(m => m.result === "loss").length);
  const matchesPlayed = Number(profile?.matches_played ?? history.length);
  const winRate = matchesPlayed > 0 ? Math.round((wins / matchesPlayed) * 100) : 0;
  const displayName = profile?.display_name ?? String(user.user_metadata?.display_name ?? "Gracz");

  return <main className="shell">
    <header className="nav">
      <Link href="/" className="brand"><span className="brand-mark">⌖</span> BOXFN</Link>
      <div className="navlinks"><Link href="/">Strona główna</Link><form action={signOut}><button className="btn secondary" type="submit">Wyloguj</button></form></div>
    </header>
    <section className="hero">
      <div className="eyebrow">Player profile</div>
      <h1>{displayName}</h1>
      <p>{profile?.epic_name ? `Fortnite: ${profile.epic_name}` : "Dodaj swój nick Fortnite, aby uzupełnić profil."}</p>
      <p><Link href={`/players/${user.id}`}>Zobacz publiczny profil →</Link></p>
      <span className="pill">Zalogowano</span>
    </section>
    {params.error && <p className="error">{params.error === "invalid" ? "Sprawdź długość nazw." : "Nie udało się zapisać zmian."}</p>}
    {params.message === "saved" && <div className="notice">Profil został zapisany.</div>}
    <section className="grid" style={{marginBottom:18}}>
      <article className="card"><div className="muted">Rozegrane mecze</div><div className="stat">{matchesPlayed}</div></article>
      <article className="card"><div className="muted">Wygrane</div><div className="stat">{wins}</div></article>
      <article className="card"><div className="muted">Win rate</div><div className="stat">{winRate}%</div></article>
      <article className="card"><div className="muted">Przegrane</div><div className="stat">{losses}</div></article>
      <article className="card"><div className="muted">Ranking ELO</div><div className="stat">{Number(profile?.elo_rating ?? 1000)}</div></article>
    </section>
    <section className="card" style={{marginBottom:18}}>
      <h2>Edytuj profil</h2>
      <form className="form" action={updateProfile}>
        <label>Nazwa wyświetlana<input name="display_name" minLength={2} maxLength={24} required defaultValue={profile?.display_name ?? displayName}/></label>
        <label>Nick Fortnite<input name="epic_name" maxLength={32} defaultValue={profile?.epic_name ?? ""} placeholder="Twój nick"/></label>
        <button className="btn" type="submit">Zapisz profil</button>
      </form>
      <p className="muted">E-mail konta: {user.email ?? "Brak adresu e-mail"}</p>
    </section>
    <section className="card">
      <div className="row"><h2>Historia meczów</h2><span className="pill">Ostatnie 50</span></div>
      {history.length === 0 ? <div className="empty">Nie masz jeszcze meczów w historii. Gdy backend zacznie zapisywać uczestnictwo i wyniki, pojawią się tutaj.</div> :
        <div style={{overflowX:"auto"}}><table><thead><tr><th>Data</th><th>Tryb</th><th>Kolejka</th><th>Wynik</th></tr></thead><tbody>
          {history.map(match => <tr key={match.id}><td>{new Date(match.created_at).toLocaleDateString("pl-PL")}</td><td>{match.game_mode} · {match.team_size}v{match.team_size}</td><td>{match.queue_type === "ranked" ? "Ranking" : "Wagers"}</td><td><span className="pill" style={match.result === "win" ? {} : {background:"#382124",color:"#ffaaaa"}}>{match.result === "win" ? "Wygrana" : match.result === "loss" ? "Przegrana" : match.result === "draw" ? "Remis" : "Do rozstrzygnięcia"}</span></td></tr>)}
        </tbody></table></div>}
    </section>
    <footer>BOXFN · Profil gracza · Saldo tokenów i wypłaty nie są implementowane w tym starterze.</footer>
  </main>;
}
