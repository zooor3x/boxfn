"use server";

import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

function value(formData: FormData, key: string) {
  return String(formData.get(key) ?? "").trim();
}

export async function signUp(formData: FormData) {
  const email = value(formData, "email").toLowerCase();
  const password = String(formData.get("password") ?? "");
  const displayName = value(formData, "display_name");
  const epicName = value(formData, "epic_name");

  if (!email || password.length < 10 || displayName.length < 2 || displayName.length > 24 || epicName.length > 32) {
    redirect("/signup?error=invalid");
  }

  const supabase = await createClient();
  const { error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: { display_name: displayName, epic_name: epicName || null },
      emailRedirectTo: `${process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000"}/auth/callback`,
    },
  });

  if (error) redirect("/signup?error=signup");
  redirect("/login?message=check-email");
}

export async function signIn(formData: FormData) {
  const email = value(formData, "email").toLowerCase();
  const password = String(formData.get("password") ?? "");
  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) redirect("/login?error=credentials");
  redirect("/profile");
}

export async function signOut() {
  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect("/");
}

export async function updateProfile(formData: FormData) {
  const displayName = value(formData, "display_name");
  const epicName = value(formData, "epic_name");
  if (displayName.length < 2 || displayName.length > 24 || epicName.length > 32) {
    redirect("/profile?error=invalid");
  }

  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { error } = await supabase.from("profiles").update({
    display_name: displayName,
    epic_name: epicName || null,
    updated_at: new Date().toISOString(),
  }).eq("id", user.id);

  if (error) redirect("/profile?error=save");
  redirect("/profile?message=saved");
}
