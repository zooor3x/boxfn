import Link from "next/link";
import { signIn } from "@/app/actions";

export default async function LoginPage({ searchParams }: { searchParams: Promise<{error?: string; message?: string}> }) {
  const { error, message } = await searchParams;
  return <main className="shell">
    <header className="nav"><Link href="/" className="brand"><span className="brand-mark">⌖</span> BOXFN</Link><Link href="/signup">Utwórz konto</Link></header>
    <section className="hero"><div className="eyebrow">Witaj ponownie</div><h1>Zaloguj się.</h1><p>Wróć do swojego profilu i historii meczów.</p></section>
    <section className="card">
      {message === "check-email" && <div className="notice">Jeśli potwierdzenie e-mail jest włączone, sprawdź skrzynkę, aby aktywować konto.</div>}
      {error && <p className="error">Nieprawidłowy e-mail lub hasło albo konto nie zostało jeszcze potwierdzone.</p>}
      <form className="form" action={signIn}>
        <label>Adres e-mail<input type="email" name="email" required autoComplete="email"/></label>
        <label>Hasło<input type="password" name="password" required autoComplete="current-password"/></label>
        <button className="btn" type="submit">Zaloguj się</button>
      </form>
    </section>
  </main>;
}
