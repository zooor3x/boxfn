import Link from "next/link";
import { createClient } from "@/lib/supabase/server";

type Player = { id: string; display_name: string; epic_name: string | null; matches_played: number; wins: number; elo_rating: number };

export default async function PlayersPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { q = "" } = await searchParams;
  const query = q.trim().slice(0, 32);
  const supabase = await createClient();
  let players: Player[] = [];
  let errorMessage = "";

  if (query.length >= 2) {
    const safe = query.replace(/[,%()]/g, " ").trim();
    if (safe.length >= 2) {
      const { data, error } = await supabase
        .from("profiles")
        .select("id, display_name, epic_name, matches_played, wins, elo_rating")
        .or(`display_name.ilike.%${safe}%,epic_name.ilike.%${safe}%`)
        .order("elo_rating", { ascending: false })
        .limit(30);
      if (error) errorMessage = "Nie udało się wyszukać graczy. Sprawdź konfigurację Supabase.";
      else players = (data ?? []) as Player[];
    }
  }

  return <main className="shell">
    <header className="nav">
      <Link href="/" className="brand"><span className="brand-mark">⌖</span> BOXFN</Link>
      <nav className="navlinks"><Link href="/">Strona główna</Link><Link href="/profile">Mój profil</Link></nav>
    </header>
    <section className="hero">
      <div className="eyebrow">Community</div>
      <h1>Znajdź gracza.</h1>
      <p>Szukaj po nazwie BOXFN lub nicku Fortnite i sprawdź publiczne statystyki.</p>
    </section>
    <section className="card">
      <form method="get" className="form">
        <label>Nick gracza<input name="q" minLength={2} maxLength={32} defaultValue={query} placeholder="np. BoxKing" /></label>
        <button className="btn" type="submit">Szukaj profilu</button>
      </form>
      <p className="muted">Wpisz co najmniej 2 znaki. Wyniki są ograniczone do 30 profili.</p>
    </section>
    {errorMessage && <p className="error">{errorMessage}</p>}
    {query.length >= 2 && !errorMessage && <section className="card" style={{marginTop:18}}>
      <div className="row"><h2>Wyniki wyszukiwania</h2><span className="pill">{players.length} profili</span></div>
      {players.length === 0 ? <div className="empty">Nie znaleziono graczy dla „{query}”.</div> :
        <div className="grid">
          {players.map(player => {
            const matches = Number(player.matches_played ?? 0);
            const wins = Number(player.wins ?? 0);
            const rate = matches > 0 ? Math.round(wins / matches * 100) : 0;
            return <article className="card" key={player.id}>
              <div className="row"><span className="pill">ELO {player.elo_rating ?? 1000}</span><span className="muted">{rate}% win rate</span></div>
              <h2 style={{marginTop:14}}>{player.display_name}</h2>
              <p>{player.epic_name ? `Fortnite: ${player.epic_name}` : "Brak nicku Fortnite"}</p>
              <p className="muted">{matches} meczów · {wins} wygranych</p>
              <Link className="btn" href={`/players/${player.id}`}>Otwórz profil →</Link>
            </article>;
          })}
        </div>}
    </section>}
    <footer>BOXFN · Wyszukiwarka publicznych profili graczy</footer>
  </main>;
}
