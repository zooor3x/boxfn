import Link from "next/link";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export default async function PublicPlayerPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const supabase = await createClient();
  const { data: player, error } = await supabase
    .from("profiles")
    .select("id, display_name, epic_name, created_at, matches_played, wins, losses, elo_rating")
    .eq("id", id)
    .maybeSingle();

  if (error || !player) notFound();

  const matches = Number(player.matches_played ?? 0);
  const wins = Number(player.wins ?? 0);
  const losses = Number(player.losses ?? 0);
  const rate = matches > 0 ? Math.round(wins / matches * 100) : 0;

  return <main className="shell">
    <header className="nav">
      <Link href="/" className="brand"><span className="brand-mark">⌖</span> BOXFN</Link>
      <nav className="navlinks"><Link href="/players">Szukaj graczy</Link><Link href="/profile">Mój profil</Link></nav>
    </header>
    <section className="hero">
      <div className="eyebrow">Public player profile</div>
      <h1>{player.display_name}</h1>
      <p>{player.epic_name ? `Fortnite: ${player.epic_name}` : "Nick Fortnite nie został dodany."}</p>
      <p className="muted">Gracz BOXFN od {new Date(player.created_at).toLocaleDateString("pl-PL")}</p>
    </section>
    <section className="grid">
      <article className="card"><div className="muted">Ranking ELO</div><div className="stat">{player.elo_rating ?? 1000}</div></article>
      <article className="card"><div className="muted">Rozegrane mecze</div><div className="stat">{matches}</div></article>
      <article className="card"><div className="muted">Wygrane</div><div className="stat">{wins}</div></article>
      <article className="card"><div className="muted">Przegrane</div><div className="stat">{losses}</div></article>
      <article className="card"><div className="muted">Win rate</div><div className="stat">{rate}%</div></article>
    </section>
    <section className="card" style={{marginTop:18}}>
      <h2>Historia meczów</h2>
      <p>Publiczny profil pokazuje statystyki zbiorcze. Szczegółowa historia wyników pozostaje prywatna dla zalogowanego gracza w tej wersji.</p>
      <Link href="/players" className="btn secondary">← Wróć do wyszukiwarki</Link>
    </section>
    <footer>BOXFN · Statystyki wyliczane z potwierdzonych wyników zapisanych przez zaufany backend.</footer>
  </main>;
}
