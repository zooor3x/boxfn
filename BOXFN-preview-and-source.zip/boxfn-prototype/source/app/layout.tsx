import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "BOXFN — Fortnite Competitive",
  description: "BOXFN player accounts and match history prototype.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="pl"><body>{children}</body></html>;
}
