import Link from "next/link";
import { signUp } from "@/app/actions";

export default async function SignupPage({ searchParams }: { searchParams: Promise<{error?: string}> }) {
  const { error } = await searchParams;
  return <main className="shell">
    <header className="nav"><Link href="/" className="brand"><span className="brand-mark">⌖</span> BOXFN</Link><Link href="/login">Masz już konto? Zaloguj się</Link></header>
    <section className="hero"><div className="eyebrow">Dołącz do społeczności</div><h1>Utwórz konto.</h1><p>Załóż konto gracza BOXFN. Hasło musi mieć co najmniej 10 znaków.</p></section>
    <section className="card">
      {error && <p className="error">{error === "invalid" ? "Sprawdź pola. Nazwa gracza: 2–24 znaki; hasło: minimum 10 znaków." : "Nie udało się utworzyć konta. Spróbuj ponownie lub sprawdź konfigurację Supabase."}</p>}
      <form className="form" action={signUp}>
        <label>Nazwa wyświetlana<input name="display_name" minLength={2} maxLength={24} required autoComplete="nickname" placeholder="np. BoxKing"/></label>
        <label>Nick Fortnite (opcjonalnie)<input name="epic_name" maxLength={32} autoComplete="off" placeholder="Twój nick w grze"/></label>
        <label>Adres e-mail<input type="email" name="email" required autoComplete="email" placeholder="ty@example.com"/></label>
        <label>Hasło<input type="password" name="password" required minLength={10} autoComplete="new-password" placeholder="Minimum 10 znaków"/></label>
        <button className="btn" type="submit">Utwórz konto</button>
      </form>
      <p className="muted">W zależności od ustawień Supabase, przed pierwszym logowaniem może być wymagane potwierdzenie e-maila.</p>
    </section>
  </main>;
}
